document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registrationForm');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Validate form
        if (!form.checkValidity()) {
            alert('Please fill out all required fields.');
            return;
        }

        // Assuming the payment page is payment.html
        const paymentPageURL = 'payment.html';

        // Optionally, you can pass form data to the payment page if needed
        // Here, just a simple navigation
        window.location.href = paymentPageURL;
    });
});
